import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ecommerce_app/pages/product_details.dart';

class Products extends StatefulWidget {
  @override
  _ProductsState createState() => _ProductsState();
}

class _ProductsState extends State<Products> {
  var product_list = [
    {
      'name': 'Blazer',
      'picture': 'images/products/blazer.jpg',
      'old_price': 120,
      'price': 85,
    },
    {
      'name': 'Snikers',
      'picture': 'images/products/shoes.jpg',
      'old_price': 100, //Image carousel
      'price': 50,
    },
    {
      'name': 'Tip Dress',
      'picture': 'images/products/dress.jpg',
      'old_price': 65, //Image carousel
      'price': 57,
    },
    {
      'name': 'Fip Shirt',
      'picture': 'images/products/shirt.jpg',
      'old_price': 30, //Image carousel
      'price': 18,
    },
    {
      'name': 'SPants',
      'picture': 'images/products/sweaterpants.jpg',
      'old_price': 123, //Image carousel
      'price': 99,
    },
    {
      'name': 'R Snikers',
      'picture': 'images/products/snikers.webp',
      'old_price': 32, //Image carousel
      'price': 11,
    },
  ];
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      itemCount: product_list.length,
      gridDelegate:
          SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
      itemBuilder: (context, int index) => SingleProduct(
        prod_name: product_list[index]['name'],
        prod_picture: product_list[index]['picture'],
        prod_oldprice: product_list[index]['old_price'],
        prod_price: product_list[index]['price'],
        isFavorite: false,
      ),
    );
  }
}

//**********Product Details*********
class SingleProduct extends StatelessWidget {
  final String prod_name;
  final prod_picture;
  final prod_oldprice;
  final prod_price;
  bool isFavorite;
  SingleProduct(
      {this.prod_name,
      this.prod_picture,
      this.prod_oldprice,
      this.prod_price,
      this.isFavorite});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 5.0, bottom: 2.0, left: 5.0, right: 5.0),
      child: InkWell(
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(
//passing the values of the product to the productDetails page
              builder: (context) => ProductDetails(
                productDetailsName: prod_name,
                productDetailsOldPrice: prod_oldprice,
                productDetailsPicture: prod_picture,
                productDetailsPrice: prod_price,
              ),
            ),
          );
        },
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15.0),
              boxShadow: [
                BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 3.0,
                    blurRadius: 5.0),
              ],
              color: Colors.white),
          child: Column(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.all(5.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    isFavorite
                        ? Icon(
                            Icons.favorite,
                            color: Colors.red,
                          )
                        : Icon(
                            Icons.favorite_border,
                            color: Colors.red,
                          ),
                  ],
                ),
              ),
              Hero(
                tag: prod_picture,
                child: Container(
                  height: 85.0,
                  width: 85.0,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(
                          prod_picture,
                        ),
                        fit: BoxFit.contain),
                  ),
                ),
              ),
              SizedBox(
                height: 5.0,
              ),
              Text(
                prod_name,
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(
                height: 5.0,
              ),
              Padding(
                padding: EdgeInsets.only(
                  bottom: 0.0,
                ),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        '\$$prod_oldprice',
                        style:
                            TextStyle(decoration: TextDecoration.lineThrough),
                      ),
                      SizedBox(
                        width: 15.0,
                      ),
                      Text(
                        '\$$prod_price',
                        style: TextStyle(color: Colors.red),
                      ),
                    ]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

//Card(
//child: Hero(
//tag: prod_name,
//child: Material(
//child: InkWell(
//onTap: () => Navigator.of(context).push(
//MaterialPageRoute(
////passing the values of the product to the productDetails page
//builder: (context) => ProductDetails(
//productDetailsName: prod_name,
//productDetailsOldPrice: prod_oldprice,
//productDetailsPicture: prod_picture,
//productDetailsPrice: prod_price,
//),
//),
//),
//child: GridTile(
//footer: Container(
//color: Colors.white70,
//child: ListTile(
//leading: Text(
//prod_name,
//style: TextStyle(fontWeight: FontWeight.bold),
//),
//title: Text(
//'\$$prod_price',
//style: TextStyle(
//color: Colors.black,
//fontWeight: FontWeight.w800,
//),
//),
//subtitle: Text(
//'\$$prod_oldprice',
//style: TextStyle(
//color: Colors.black45,
//fontWeight: FontWeight.w800,
//decoration: TextDecoration.lineThrough,
//),
//),
//),
//),
//child: Image.asset(
//prod_picture,
//fit: BoxFit.cover,
//)),
//),
//),
//),
//);
